package com.example.splashscrreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Cocacola extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cocacola);
    }
}