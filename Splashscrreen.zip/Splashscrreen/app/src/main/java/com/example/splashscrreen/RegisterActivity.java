package com.example.splashscrreen;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.FirebaseFirestore;

public class RegisterActivity extends AppCompatActivity {

    String collectionName = "Delivery";
    
    EditText etUsername, etPassowrd;
    FloatingActionButton fabRegister = findViewById(R.id.fab_register);

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etUsername = findViewById(R.id.et_username);
        etPassowrd = findViewById(R.id.et_password);
        fabRegister = findViewById(R.id.fab_register);

        fabRegister.setOnClickListener(v -> addData());
    }

    void addData() {
        String username = etUsername.getText().toString();
        String password = etPassowrd.getText().toString();
        RegisterModel registerModel = new RegisterModel(null, username,password);

        db.collection(collectionName).add(registerModel)
                .addOnSuccessListener(documentReference -> Toast.makeText(this,"Success", Toast.LENGTH_LONG).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show());
        }
    }

