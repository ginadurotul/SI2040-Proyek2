package com.example.splashscrreen;

public class User {

    public String Username, Password;
    public User(){

    }

    public User(String Username, String Password){
        this.Username = Username;
        this.Password = Password;
    }
}
