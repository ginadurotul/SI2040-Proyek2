package com.example.splashscrreen;

public class LoginModel {
}
